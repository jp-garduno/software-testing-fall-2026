class AccountState {
  static PENDING = "Pending";
  static ACTIVE = "Active";
  static SUSPENDED = "Suspended";
  static LOCKED = "Locked";
  static DORMANT = "Dormant";
  static DELETED = "Deleted";
  static PERMANENTLY_DELETED = "Permanently Deleted";
}

const DAY_MS = 24 * 60 * 60 * 1000;

class UserAccount {
  constructor(userId, email) {
    this.userId = userId;
    this.email = email;
    this.state = AccountState.PENDING;
    this.createdAt = new Date();
    this.lastActivityAt = new Date();
    this.deletedAt = null;
    this.suspensionReason = null;
    this.lockReason = null;
    this.securityReviewApproved = false;
    this.stateBeforeDeletion = null;
    this.history = [{ state: AccountState.PENDING, timestamp: new Date() }];
  }

  _transition(newState, message) {
    const oldState = this.state;
    this.state = newState;
    this.history.push({ state: newState, timestamp: new Date() });
    return { success: true, message: `${oldState} -> ${newState}: ${message}` };
  }

  _reject(message) {
    return {
      success: false,
      message: `Invalid transition from ${this.state}: ${message}`,
    };
  }

  _daysSince(date) {
    return (Date.now() - date.getTime()) / DAY_MS;
  }

  _expireDeletedAccount() {
    this._transition(
      AccountState.PERMANENTLY_DELETED,
      "Account permanently deleted after 30 days",
    );
    return {
      success: false,
      message: "Cannot restore account after 30 days; account is permanently deleted",
    };
  }

  verifyEmail() {
    if (this.state !== AccountState.PENDING) {
      return this._reject("Can only verify pending accounts");
    }

    if (this._daysSince(this.createdAt) >= 7) {
      this.stateBeforeDeletion = AccountState.PENDING;
      this.deletedAt = new Date();
      this._transition(
        AccountState.DELETED,
        "Account deleted because the email verification deadline expired",
      );
      return {
        success: false,
        message: "Email verification deadline expired; account was soft deleted",
      };
    }

    return this._transition(AccountState.ACTIVE, "Email verified");
  }

  suspendAccount(reason) {
    if (this.state !== AccountState.ACTIVE) {
      return this._reject("Can only suspend active accounts");
    }

    this.suspensionReason = reason;
    return this._transition(AccountState.SUSPENDED, `Suspended: ${reason}`);
  }

  lockAccount(reason) {
    if (
      this.state !== AccountState.ACTIVE &&
      this.state !== AccountState.SUSPENDED
    ) {
      return this._reject("Cannot lock account in current state");
    }

    this.lockReason = reason;
    this.securityReviewApproved = false;
    return this._transition(AccountState.LOCKED, `Locked: ${reason}`);
  }

  approveSecurityReview() {
    if (this.state !== AccountState.LOCKED) {
      return this._reject("Security review only applies to locked accounts");
    }

    this.securityReviewApproved = true;
    return { success: true, message: "Security review approved" };
  }

  reactivateAccount(actorRole = "user") {
    if (this.state === AccountState.SUSPENDED) {
      if (actorRole !== "admin") {
        return this._reject("Only an admin can reactivate suspended accounts");
      }
      this.suspensionReason = null;
      this.lastActivityAt = new Date();
      return this._transition(
        AccountState.ACTIVE,
        "Account reactivated by admin after suspension",
      );
    }

    if (this.state === AccountState.DORMANT) {
      this.lastActivityAt = new Date();
      return this._transition(
        AccountState.ACTIVE,
        "Account reactivated after user login",
      );
    }

    if (this.state === AccountState.LOCKED) {
      if (!this.securityReviewApproved) {
        return this._reject("Locked accounts require an approved security review");
      }
      this.lockReason = null;
      this.securityReviewApproved = false;
      this.lastActivityAt = new Date();
      return this._transition(
        AccountState.ACTIVE,
        "Account reactivated after security review",
      );
    }

    return this._reject("Cannot reactivate account in current state");
  }

  markDormant() {
    if (this.state !== AccountState.ACTIVE) {
      return this._reject("Only active accounts can become dormant");
    }

    if (this._daysSince(this.lastActivityAt) < 180) {
      return this._reject("Account still active for fewer than 180 days");
    }

    return this._transition(
      AccountState.DORMANT,
      "Marked as dormant due to 180 days of inactivity",
    );
  }

  softDelete() {
    const deletableStates = [
      AccountState.PENDING,
      AccountState.ACTIVE,
      AccountState.SUSPENDED,
      AccountState.LOCKED,
      AccountState.DORMANT,
    ];

    if (!deletableStates.includes(this.state)) {
      return this._reject("Cannot delete account in current state");
    }

    this.stateBeforeDeletion = this.state;
    this.deletedAt = new Date();
    return this._transition(AccountState.DELETED, "Account soft deleted");
  }

  restoreAccount() {
    if (this.state !== AccountState.DELETED) {
      return this._reject("Can only restore deleted accounts");
    }

    if (this._daysSince(this.deletedAt) >= 30) {
      return this._expireDeletedAccount();
    }

    const restoredState = this.stateBeforeDeletion || AccountState.ACTIVE;
    this.deletedAt = null;
    this.stateBeforeDeletion = null;
    return this._transition(restoredState, "Account restored to its prior state");
  }

  hardDelete() {
    if (this.state !== AccountState.DELETED) {
      return this._reject("Can only permanently delete soft-deleted accounts");
    }

    if (this._daysSince(this.deletedAt) < 30) {
      return this._reject("Can only hard delete after 30 days");
    }

    return this._transition(
      AccountState.PERMANENTLY_DELETED,
      "Account permanently deleted",
    );
  }

  processLifecycle() {
    if (this.state === AccountState.PENDING && this._daysSince(this.createdAt) >= 7) {
      return this.softDelete();
    }

    if (this.state === AccountState.ACTIVE && this._daysSince(this.lastActivityAt) >= 180) {
      return this.markDormant();
    }

    if (this.state === AccountState.DELETED && this._daysSince(this.deletedAt) >= 30) {
      return this.hardDelete();
    }

    return { success: false, message: "No lifecycle transition required" };
  }

  getState() {
    return this.state;
  }

  getHistory() {
    return this.history;
  }
}

module.exports = { UserAccount, AccountState, DAY_MS };
