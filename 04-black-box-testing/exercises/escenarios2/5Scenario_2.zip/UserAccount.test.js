const { UserAccount, AccountState, DAY_MS } = require("./UserAccount");

function createActiveAccount() {
  const account = new UserAccount("user-1", "student@example.com");
  account.verifyEmail();
  return account;
}

function invoke(account, event) {
  const actions = {
    verifyEmail: () => account.verifyEmail(),
    suspendAccount: () => account.suspendAccount("Policy violation"),
    lockAccount: () => account.lockAccount("Suspicious sign-in"),
    approveSecurityReview: () => account.approveSecurityReview(),
    reactivateAccount: () => account.reactivateAccount("admin"),
    markDormant: () => account.markDormant(),
    softDelete: () => account.softDelete(),
    restoreAccount: () => account.restoreAccount(),
    hardDelete: () => account.hardDelete(),
  };
  return actions[event]();
}

describe("User Account Lifecycle", () => {
  test("starts in Pending and records the initial state", () => {
    const account = new UserAccount("user-0", "student@example.com");
    expect(account.getState()).toBe(AccountState.PENDING);
    expect(account.getHistory()).toHaveLength(1);
  });

  test("Pending -> Active when the email is verified before day 7", () => {
    const account = new UserAccount("user-1", "student@example.com");
    expect(account.verifyEmail().success).toBe(true);
    expect(account.getState()).toBe(AccountState.ACTIVE);
  });

  test("Pending -> Deleted automatically at exactly 7 days", () => {
    const account = new UserAccount("user-2", "student@example.com");
    account.createdAt = new Date(Date.now() - 7 * DAY_MS);
    expect(account.processLifecycle().success).toBe(true);
    expect(account.getState()).toBe(AccountState.DELETED);
  });

  test("email verification at the 7-day boundary cannot bypass deletion", () => {
    const account = new UserAccount("user-3", "student@example.com");
    account.createdAt = new Date(Date.now() - 7 * DAY_MS);
    expect(account.verifyEmail().success).toBe(false);
    expect(account.getState()).toBe(AccountState.DELETED);
  });

  test("Active -> Suspended stores the policy reason", () => {
    const account = createActiveAccount();
    expect(account.suspendAccount("Harassment").success).toBe(true);
    expect(account.getState()).toBe(AccountState.SUSPENDED);
    expect(account.suspensionReason).toBe("Harassment");
  });

  test("Suspended -> Active requires an admin", () => {
    const account = createActiveAccount();
    account.suspendAccount("Harassment");
    expect(account.reactivateAccount("user").success).toBe(false);
    expect(account.reactivateAccount("admin").success).toBe(true);
    expect(account.getState()).toBe(AccountState.ACTIVE);
    expect(account.suspensionReason).toBeNull();
  });

  test("Active and Suspended accounts can be locked", () => {
    const active = createActiveAccount();
    const suspended = createActiveAccount();
    suspended.suspendAccount("Harassment");
    expect(active.lockAccount("New device").success).toBe(true);
    expect(suspended.lockAccount("New device").success).toBe(true);
    expect(active.getState()).toBe(AccountState.LOCKED);
    expect(suspended.getState()).toBe(AccountState.LOCKED);
  });

  test("Locked -> Active is rejected until security review is approved", () => {
    const account = createActiveAccount();
    account.lockAccount("New device");
    expect(account.reactivateAccount().success).toBe(false);
    expect(account.approveSecurityReview().success).toBe(true);
    expect(account.reactivateAccount().success).toBe(true);
    expect(account.getState()).toBe(AccountState.ACTIVE);
    expect(account.lockReason).toBeNull();
  });

  test("Active -> Dormant at exactly 180 days", () => {
    const account = createActiveAccount();
    account.lastActivityAt = new Date(Date.now() - 180 * DAY_MS);
    expect(account.processLifecycle().success).toBe(true);
    expect(account.getState()).toBe(AccountState.DORMANT);
  });

  test("Active stays Active before 180 days", () => {
    const account = createActiveAccount();
    account.lastActivityAt = new Date(Date.now() - 179 * DAY_MS);
    expect(account.markDormant().success).toBe(false);
    expect(account.getState()).toBe(AccountState.ACTIVE);
  });

  test("Dormant -> Active represents user login or reactivation", () => {
    const account = createActiveAccount();
    account.lastActivityAt = new Date(Date.now() - 181 * DAY_MS);
    account.markDormant();
    expect(account.reactivateAccount().success).toBe(true);
    expect(account.getState()).toBe(AccountState.ACTIVE);
  });

  test.each([
    AccountState.PENDING,
    AccountState.ACTIVE,
    AccountState.SUSPENDED,
    AccountState.LOCKED,
    AccountState.DORMANT,
  ])("%s -> Deleted by softDelete", (state) => {
    const account = new UserAccount("user-delete", "student@example.com");
    account.state = state;
    expect(account.softDelete().success).toBe(true);
    expect(account.getState()).toBe(AccountState.DELETED);
    expect(account.stateBeforeDeletion).toBe(state);
  });

  test("Deleted -> prior state when restored before 30 days", () => {
    const account = createActiveAccount();
    account.suspendAccount("Harassment");
    account.softDelete();
    expect(account.restoreAccount().success).toBe(true);
    expect(account.getState()).toBe(AccountState.SUSPENDED);
    expect(account.suspensionReason).toBe("Harassment");
  });

  test("Deleted -> Permanently Deleted at exactly 30 days", () => {
    const account = createActiveAccount();
    account.softDelete();
    account.deletedAt = new Date(Date.now() - 30 * DAY_MS);
    expect(account.processLifecycle().success).toBe(true);
    expect(account.getState()).toBe(AccountState.PERMANENTLY_DELETED);
  });

  test("restore at the 30-day boundary is rejected and permanently deletes", () => {
    const account = createActiveAccount();
    account.softDelete();
    account.deletedAt = new Date(Date.now() - 30 * DAY_MS);
    expect(account.restoreAccount().success).toBe(false);
    expect(account.getState()).toBe(AccountState.PERMANENTLY_DELETED);
  });

  test("hard delete before 30 days is rejected", () => {
    const account = createActiveAccount();
    account.softDelete();
    account.deletedAt = new Date(Date.now() - 29 * DAY_MS);
    expect(account.hardDelete().success).toBe(false);
    expect(account.getState()).toBe(AccountState.DELETED);
  });

  const invalidEventsByState = {
    [AccountState.PENDING]: [
      "suspendAccount", "lockAccount", "approveSecurityReview", "reactivateAccount",
      "markDormant", "restoreAccount", "hardDelete",
    ],
    [AccountState.ACTIVE]: [
      "verifyEmail", "approveSecurityReview", "reactivateAccount", "restoreAccount", "hardDelete",
    ],
    [AccountState.SUSPENDED]: [
      "verifyEmail", "suspendAccount", "approveSecurityReview", "markDormant", "restoreAccount", "hardDelete",
    ],
    [AccountState.LOCKED]: [
      "verifyEmail", "suspendAccount", "lockAccount", "markDormant", "restoreAccount", "hardDelete",
    ],
    [AccountState.DORMANT]: [
      "verifyEmail", "suspendAccount", "lockAccount", "approveSecurityReview", "markDormant", "restoreAccount", "hardDelete",
    ],
    [AccountState.DELETED]: [
      "verifyEmail", "suspendAccount", "lockAccount", "approveSecurityReview", "reactivateAccount", "markDormant", "softDelete",
    ],
    [AccountState.PERMANENTLY_DELETED]: [
      "verifyEmail", "suspendAccount", "lockAccount", "approveSecurityReview", "reactivateAccount",
      "markDormant", "softDelete", "restoreAccount", "hardDelete",
    ],
  };

  const invalidCases = Object.entries(invalidEventsByState).flatMap(([state, events]) =>
    events.map((event) => [state, event]),
  );

  test.each(invalidCases)("invalid transition: %s with %s keeps the state", (state, event) => {
    const account = new UserAccount("user-invalid", "student@example.com");
    account.state = state;
    if (state === AccountState.DELETED) {
      account.deletedAt = new Date();
    }
    expect(invoke(account, event).success).toBe(false);
    expect(account.getState()).toBe(state);
  });

  test("Permanently Deleted is terminal", () => {
    const account = createActiveAccount();
    account.softDelete();
    account.deletedAt = new Date(Date.now() - 31 * DAY_MS);
    account.hardDelete();
    expect(account.getState()).toBe(AccountState.PERMANENTLY_DELETED);
    expect(account.getHistory().at(-1).state).toBe(AccountState.PERMANENTLY_DELETED);
  });
});
