# Decision Table — Sistema de Autenticación Multifactor

Orden de evaluación de las condiciones (importante porque varias reglas se
solapan): **Usuario existe → Suspendida → Bloqueada por admin → Bloqueo
temporal vigente → Password → 2FA**. Una cuenta suspendida o bloqueada por
admin se rechaza *sin importar* si el password es correcto, para no filtrar
esa información a un atacante.

| Rule # | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **Conditions** | | | | | | | | | | | | | |
| Username exists? | F | T | T | T | T | T | T | T | T | T | T | T | T |
| Account status | - | Active | Active | Suspended | Suspended | Locked | Locked | Active | Active | Active | Active | Active | Active |
| Time-lock vigente? | - | - | - | - | - | - | - | T | T | F | F | F | F |
| Password correcto? | - | F | T | F | T | F | T | F | T | F | F | F | T |
| Failed attempts (tras este intento) | - | 0-2 | - | - | - | - | - | - | - | 3-4 | 5+ | - | - |
| 2FA enabled? | - | - | - | - | - | - | - | - | - | - | - | - | F |
| 2FA code correcto? | - | - | - | - | - | - | - | - | - | - | - | - | - |
| **Actions** | | | | | | | | | | | | | |
| Grant access | - | - | X | - | - | - | - | - | - | - | - | - | X |
| User not found | X | - | - | - | - | - | - | - | - | - | - | - | - |
| Wrong password | - | X | - | - | - | - | - | - | - | X | - | - | - |
| Account suspended | - | - | - | X | X | - | - | - | - | - | - | - | - |
| Account locked (admin) | - | - | - | - | - | X | X | - | - | - | - | - | - |
| Too many attempts | - | - | - | - | - | - | - | X | X | - | X | - | - |
| Prompt 2FA | - | - | - | - | - | - | - | - | - | - | - | X | - |
| Wrong 2FA | - | - | - | - | - | - | - | - | - | - | - | - | - |
| Increment fails | - | X | - | - | - | - | - | - | - | X | X | - | - |
| Reset fails | - | - | X | - | - | - | - | - | - | - | - | - | X |
| Send alert | - | - | - | - | - | - | - | - | - | X | X | - | - |

Reglas adicionales (2FA, con password correcto y cuenta activa, sin bloqueo
vigente — cubren las combinaciones de la columna 13 con 2FA=T):

| Rule # | 14 | 15 | 16 |
|---|---|---|---|
| 2FA enabled? | T | T | T |
| 2FA code provisto? | F (None) | T | T |
| 2FA code correcto? | - | T | F |
| Grant access | - | X | - |
| Prompt 2FA | X | - | - |
| Wrong 2FA | - | - | X |
| Reset fails | - | X | - |

Notas de diseño:
- **Suspendida/Locked por admin tienen prioridad sobre el password** (reglas
  4-7): no importa si el password es correcto, se rechaza igual.
- **El bloqueo temporal (`locked_until`) también tiene prioridad sobre el
  password** (reglas 8-9): si no, bastaría con saber el password para saltarse
  el lockout de 30 min.
- **"Failed attempts" se evalúa DESPUÉS de sumar el intento actual**: por eso
  la regla 11 (que cruza de 4→5) ya cae en "Too many attempts" en el mismo
  intento que lo provoca.
- **Un password correcto siempre resetea el contador** (reglas 3, 13-16),
  incluso si el usuario estaba en zona de warning.
- **Un 2FA incorrecto no incrementa el contador de password** (regla 16):
  son contadores conceptualmente distintos; el password ya se validó.
