"""Sistema de autenticacion multifactor con bloqueo de cuenta.

La logica de authenticate() sigue el orden de prioridad de la tabla de
decision (ver decision_table.md):

    1. Usuario no existe
    2. Cuenta suspendida            (bloquea antes de mirar el password)
    3. Cuenta bloqueada por admin   (bloquea antes de mirar el password)
    4. Bloqueo temporal por intentos fallidos (locked_until vigente)
    5. Password incorrecto -> incrementa contador y clasifica por zona
       (0-2 normal / 3-4 warning+alerta / 5+ bloqueo+alerta)
    6. Password correcto -> resetea contador, evalua 2FA si aplica
"""

from datetime import datetime, timedelta
from enum import Enum


class AuthResult(Enum):
    SUCCESS = "Access granted"
    USER_NOT_FOUND = "User not found"
    WRONG_PASSWORD = "Incorrect password"
    ACCOUNT_SUSPENDED = "Account suspended"
    ACCOUNT_LOCKED = "Account locked by administrator"
    TOO_MANY_ATTEMPTS = "Account locked due to too many failed attempts"
    REQUIRES_2FA = "2FA code required"
    WRONG_2FA = "Incorrect 2FA code"


class User:
    def __init__(self, username, password_hash, status="active",
                 two_fa_enabled=False, two_fa_secret="123456"):
        self.username = username
        self.password_hash = password_hash
        self.status = status  # active, suspended, locked
        self.two_fa_enabled = two_fa_enabled
        self.two_fa_secret = two_fa_secret  # codigo 2FA "correcto" para pruebas
        self.failed_attempts = []
        self.locked_until = None


class AuthenticationSystem:
    WARNING_THRESHOLD = 3   # a partir de este numero de fallos -> alerta
    LOCKOUT_THRESHOLD = 5   # a partir de este numero de fallos -> bloqueo
    LOCKOUT_DURATION_MINUTES = 30

    def __init__(self):
        self.users = {}

    def authenticate(self, username, password, two_fa_code=None):
        """
        Autentica un usuario segun la tabla de decision.
        Returns: (AuthResult, should_increment_fails, should_send_alert)
        """
        # Regla 1: el usuario no existe en la base de datos.
        if username not in self.users:
            return AuthResult.USER_NOT_FOUND, False, False

        user = self.users[username]

        # Regla 5: una cuenta suspendida se rechaza ANTES de revisar el
        # password, para no filtrar si el password era correcto o no.
        if user.status == "suspended":
            return AuthResult.ACCOUNT_SUSPENDED, False, False

        # Regla 6: bloqueo puesto por un administrador. Es independiente
        # del bloqueo temporal por intentos fallidos y no expira solo.
        if user.status == "locked":
            return AuthResult.ACCOUNT_LOCKED, False, False

        # Regla 4 (aun bloqueado): si el temporizador de bloqueo por
        # intentos fallidos sigue vigente, se rechaza sin mirar el
        # password -- de lo contrario el bloqueo no serviria de nada.
        if user.locked_until is not None:
            if not self.is_time_lock_expired(user):
                return AuthResult.TOO_MANY_ATTEMPTS, False, False
            # El bloqueo ya expiro: se limpia para dejar pasar el flujo normal.
            user.locked_until = None

        # Password incorrecto.
        if password != user.password_hash:
            user.failed_attempts.append(datetime.now())
            recent_fails = self.get_recent_failed_attempts(user)

            if recent_fails >= self.LOCKOUT_THRESHOLD:
                # Este intento es el que cruza el umbral de bloqueo.
                user.locked_until = datetime.now() + timedelta(
                    minutes=self.LOCKOUT_DURATION_MINUTES
                )
                return AuthResult.TOO_MANY_ATTEMPTS, True, True

            if recent_fails >= self.WARNING_THRESHOLD:
                # Zona de warning (3-4 intentos): se avisa por correo.
                return AuthResult.WRONG_PASSWORD, True, True

            # Zona normal (0-2 intentos).
            return AuthResult.WRONG_PASSWORD, True, False

        # Password correcto: se resetea el contador de fallos porque el
        # usuario legitimo no debe seguir "castigado" por errores previos.
        user.failed_attempts = []

        if user.two_fa_enabled:
            if two_fa_code is None:
                return AuthResult.REQUIRES_2FA, False, False
            if two_fa_code != user.two_fa_secret:
                # El password ya fue validado, asi que un 2FA erroneo no
                # retroalimenta el contador de fallos de password.
                return AuthResult.WRONG_2FA, False, False
            return AuthResult.SUCCESS, False, False

        return AuthResult.SUCCESS, False, False

    def get_recent_failed_attempts(self, user):
        """Get number of failed attempts in last 30 minutes."""
        thirty_mins_ago = datetime.now() - timedelta(minutes=30)
        return len([t for t in user.failed_attempts if t > thirty_mins_ago])

    def is_time_lock_expired(self, user):
        """Check if time-based lock has expired."""
        if user.locked_until is None:
            return True
        return datetime.now() > user.locked_until
