"""
Casos de prueba para el sistema de autenticacion multifactor.

Cada test cubre UNA fila de decision_table.md. El nombre del test y el
docstring indican que regla se esta probando y, sobre todo, POR QUE ese
caso es importante (que comportamiento del negocio se rompe si el test
falla).
"""

from datetime import datetime, timedelta

from auth_system import AuthenticationSystem, AuthResult, User


# ---------------------------------------------------------------------------
# Regla 1: usuario inexistente
# ---------------------------------------------------------------------------

def test_rule_user_not_found():
    """Por que: si el username no existe, el sistema debe rechazar sin
    tocar contadores ni mandar alertas -- no hay una cuenta a la que
    incrementarle intentos fallidos. (Nota: aqui NO se prueba timing-attack
    resistance, solo el valor de retorno; eso requeriria medir latencia,
    que queda fuera del alcance de este test)."""
    auth = AuthenticationSystem()
    result, increment, alert = auth.authenticate("nonexistent", "password")
    assert result == AuthResult.USER_NOT_FOUND
    assert increment is False
    assert alert is False


# ---------------------------------------------------------------------------
# Regla 2: password incorrecto, zona normal (0-2 intentos)
# ---------------------------------------------------------------------------

def test_rule_wrong_password_first_attempt():
    """Por que: el primer error de password es normal (usuarios se
    equivocan tecleando). Debe incrementar el contador para llevar la
    cuenta, pero NO debe disparar una alerta de seguridad todavia --
    mandar un correo por cada typo generaria fatiga de alertas."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "correct_hash", "active")
    result, increment, alert = auth.authenticate("user1", "wrong_password")
    assert result == AuthResult.WRONG_PASSWORD
    assert increment is True
    assert alert is False


def test_rule_wrong_password_boundary_enters_warning():
    """Por que: es el caso limite 2->3. Si el umbral de warning estuviera
    mal puesto (por ejemplo un off-by-one), este es el test que lo
    detecta: con 2 fallos previos + este intento = 3, YA debe mandar
    alerta, aunque el intento anterior (test de arriba) no la mandaba."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.failed_attempts = [datetime.now()] * 2
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "wrong_password")
    assert result == AuthResult.WRONG_PASSWORD
    assert increment is True
    assert alert is True


def test_rule_wrong_password_warning():
    """Por que: con 3 fallos previos + este intento = 4, seguimos en zona
    de warning (3-4), NO en bloqueo. A diferencia de los dos tests de
    "boundary" (que atacan los bordes 2->3 y 4->5), este confirma que el
    punto medio de la zona de warning es estable -- util si alguien
    reordena los if/elif y rompe el caso "de en medio" sin tocar los
    bordes."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.failed_attempts = [datetime.now()] * 3
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "wrong_password")
    assert result == AuthResult.WRONG_PASSWORD
    assert increment is True
    assert alert is True


def test_rule_wrong_password_boundary_triggers_lock():
    """Por que: es el caso limite 4->5, el momento EXACTO en que un
    intento normal debe convertirse en bloqueo. Es el test mas importante
    de todo el modulo de intentos fallidos: si el umbral de bloqueo esta
    mal, este test es el que revienta (a diferencia del test siguiente,
    que arranca ya con 5 fallos precargados)."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.failed_attempts = [datetime.now()] * 4
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "wrong_password")
    assert result == AuthResult.TOO_MANY_ATTEMPTS
    assert increment is True
    assert alert is True
    assert user.locked_until is not None


# ---------------------------------------------------------------------------
# Regla de bloqueo ya alcanzado / vigente
# ---------------------------------------------------------------------------

def test_rule_too_many_attempts_already_over_threshold():
    """Por que: cubre el caso en que el contador ya esta en 5+ pero el
    temporizador `locked_until` no se habia puesto (por ejemplo, datos
    precargados o una migracion). El sistema debe bloquear de inmediato
    en vez de asumir que como no hay `locked_until` la cuenta esta libre."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.failed_attempts = [datetime.now()] * 5
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "wrong_password")
    assert result == AuthResult.TOO_MANY_ATTEMPTS
    assert user.locked_until is not None


def test_rule_time_lock_blocks_even_correct_password():
    """Por que: si el password correcto pudiera saltarse el bloqueo
    temporal, el lockout de 30 minutos no serviria de nada contra un
    atacante con fuerza bruta que en algun momento da con el password
    real. El bloqueo debe respetarse SIEMPRE mientras este vigente."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.locked_until = datetime.now() + timedelta(minutes=10)
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "correct_hash")
    assert result == AuthResult.TOO_MANY_ATTEMPTS
    assert increment is False
    assert alert is False


def test_rule_time_lock_blocks_wrong_password_without_double_counting():
    """Por que: mientras el bloqueo temporal esta vigente, un intento con
    password INCORRECTO tambien debe rechazarse por TOO_MANY_ATTEMPTS (no
    por WRONG_PASSWORD) y, sobre todo, no debe seguir incrementando el
    contador ni remandando la alerta en cada intento -- si no, alguien
    podria hacer spam de intentos durante el bloqueo y saturar el correo
    de alertas o corromper el contador para cuando el bloqueo expire."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.locked_until = datetime.now() + timedelta(minutes=10)
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "wrong_password")
    assert result == AuthResult.TOO_MANY_ATTEMPTS
    assert increment is False
    assert alert is False


def test_rule_time_lock_expired_allows_login():
    """Por que: el bloqueo es TEMPORAL (30 min), no permanente. Si ya
    expiro, un usuario legitimo con el password correcto debe poder
    entrar normalmente. Sin este comportamiento, una cuenta quedaria
    bloqueada para siempre despues de 5 errores."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.locked_until = datetime.now() - timedelta(minutes=1)  # ya expiro
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "correct_hash")
    assert result == AuthResult.SUCCESS
    # Ademas el bloqueo vencido debe limpiarse, no quedar "fantasma".
    assert user.locked_until is None


# ---------------------------------------------------------------------------
# Reglas 4-5: cuenta suspendida
# ---------------------------------------------------------------------------

def test_rule_account_suspended():
    """Por que: una cuenta suspendida (por ejemplo por soporte o fraude)
    debe rechazarse aunque el password este mal, con un mensaje que
    explique la razon real en vez de un generico 'wrong password'."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "hash", "suspended")
    result, increment, alert = auth.authenticate("user1", "password")
    assert result == AuthResult.ACCOUNT_SUSPENDED
    assert increment is False
    assert alert is False


def test_rule_account_suspended_even_with_correct_password():
    """Por que: es la prueba de prioridad mas importante de seguridad:
    aunque el atacante (o el propio usuario) adivine el password
    correcto, la suspension debe seguir ganando. Si no fuera asi, este
    endpoint confirmaria en silencio que el password es correcto para
    una cuenta que deberia estar completamente bloqueada."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "correct_hash", "suspended")
    result, increment, alert = auth.authenticate("user1", "correct_hash")
    assert result == AuthResult.ACCOUNT_SUSPENDED
    assert increment is False
    assert alert is False


# ---------------------------------------------------------------------------
# Reglas 6-7: cuenta bloqueada por administrador
# ---------------------------------------------------------------------------

def test_rule_account_locked_by_admin():
    """Por que: un bloqueo puesto por un admin es distinto del bloqueo
    automatico por intentos fallidos: no tiene fecha de expiracion y solo
    un admin lo puede quitar. Debe dar un mensaje distinto para que el
    usuario sepa que no basta con esperar 30 minutos."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "hash", "locked")
    result, increment, alert = auth.authenticate("user1", "password")
    assert result == AuthResult.ACCOUNT_LOCKED
    assert increment is False
    assert alert is False


def test_rule_account_locked_by_admin_even_with_correct_password():
    """Por que: igual que con la suspension, el bloqueo de admin debe
    tener prioridad sobre un password correcto. Un admin bloqueo la
    cuenta a proposito; el sistema no debe dejarla entrar solo porque
    el password sigue siendo el mismo."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "correct_hash", "locked")
    result, increment, alert = auth.authenticate("user1", "correct_hash")
    assert result == AuthResult.ACCOUNT_LOCKED
    assert increment is False
    assert alert is False


# ---------------------------------------------------------------------------
# Password correcto: acceso, 2FA, y reseteo de contador
# ---------------------------------------------------------------------------

def test_rule_grant_access_no_2fa():
    """Por que: es el camino "feliz" mas comun -- cuenta activa, password
    correcto, sin 2FA. Debe otorgar acceso directo sin pedir nada mas.
    Este test evita que un cambio futuro en la logica de 2FA rompa el
    login de usuarios que nunca lo activaron."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "correct_hash", "active")
    result, increment, alert = auth.authenticate("user1", "correct_hash")
    assert result == AuthResult.SUCCESS
    assert increment is False
    assert alert is False


def test_rule_2fa_required():
    """Por que: si el password es correcto pero la cuenta tiene 2FA
    activado y no se mando codigo, el sistema NO debe dar acceso todavia
    -- debe pedir el segundo factor. Es la esencia de "multi-factor"."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "correct", "active", two_fa_enabled=True)
    result, increment, alert = auth.authenticate("user1", "correct", two_fa_code=None)
    assert result == AuthResult.REQUIRES_2FA
    assert increment is False
    assert alert is False


def test_rule_2fa_success():
    """Por que: con password Y codigo 2FA correctos, debe otorgar acceso.
    Por si sola esta prueba NO demuestra que el codigo se valida de
    verdad (podria pasar aunque authenticate() aceptara cualquier valor
    no-nulo) -- esa garantia solo existe en conjunto con
    test_rule_2fa_wrong_code, que prueba el mismo escenario con un
    codigo incorrecto y espera que falle."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "correct", "active", two_fa_enabled=True)
    result, increment, alert = auth.authenticate("user1", "correct", two_fa_code="123456")
    assert result == AuthResult.SUCCESS


def test_rule_2fa_wrong_code():
    """Por que: si alguien ya tiene el password (robado o adivinado) pero
    no tiene el segundo factor, debe seguir sin poder entrar. Es la
    proteccion real que aporta el 2FA -- sin este test, un bug que
    ignorara two_fa_code pasaria inadvertido."""
    auth = AuthenticationSystem()
    auth.users["user1"] = User("user1", "correct", "active", two_fa_enabled=True)
    result, increment, alert = auth.authenticate("user1", "correct", two_fa_code="000000")
    assert result == AuthResult.WRONG_2FA
    # Un 2FA erroneo no es un error de password: no debe sumarse al
    # mismo contador que dispara el bloqueo por fuerza bruta de password.
    assert increment is False


def test_successful_login_resets_failed_attempts_counter():
    """Por que: un usuario que se equivoco 3 veces (zona de warning) y
    luego acierta el password no debe seguir "cerca" del bloqueo en su
    siguiente error. El reseteo es un efecto de estado (no solo una
    bandera de retorno), asi que este test verifica directamente
    `user.failed_attempts`, no solo el resultado de authenticate()."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.failed_attempts = [datetime.now()] * 3
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "correct_hash")
    assert result == AuthResult.SUCCESS
    assert user.failed_attempts == []


# ---------------------------------------------------------------------------
# Helpers: ventana de 30 minutos y expiracion del bloqueo
# ---------------------------------------------------------------------------

def test_get_recent_failed_attempts_ignores_old_attempts():
    """Por que: la regla de negocio es 'intentos en los ultimos 30
    minutos', no 'intentos de toda la vida'. Si este helper contara
    intentos viejos, un usuario que fallo hace semanas nunca podria
    volver a intentarlo sin ser tratado como sospechoso."""
    auth = AuthenticationSystem()
    user = User("user1", "hash", "active")
    user.failed_attempts = [
        datetime.now() - timedelta(minutes=40),  # fuera de la ventana
        datetime.now() - timedelta(minutes=35),  # fuera de la ventana
        datetime.now() - timedelta(minutes=5),   # dentro de la ventana
    ]
    assert auth.get_recent_failed_attempts(user) == 1


def test_stale_failed_attempts_dont_count_towards_lockout():
    """Por que: integra el helper anterior con authenticate(). Un usuario
    con 4 fallos viejos (hace mas de 30 min) que vuelve a fallar AHORA
    deberia tratarse como si fuera su primer error reciente (zona
    normal), no como si estuviera a un paso del bloqueo."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    user.failed_attempts = [datetime.now() - timedelta(minutes=45)] * 4
    auth.users["user1"] = user

    result, increment, alert = auth.authenticate("user1", "wrong_password")
    assert result == AuthResult.WRONG_PASSWORD
    assert alert is False  # NO deberia ser warning ni bloqueo


def test_is_time_lock_expired_true_when_never_locked():
    """Por que: un usuario que nunca ha sido bloqueado (`locked_until is
    None`) debe tratarse como "no bloqueado" por defecto. Es el caso
    base que usan todos los logins normales."""
    auth = AuthenticationSystem()
    user = User("user1", "hash", "active")
    assert auth.is_time_lock_expired(user) is True


def test_is_time_lock_expired_false_while_still_locked():
    """Por que: si `locked_until` esta en el futuro, el helper debe decir
    que el bloqueo NO ha expirado. Es la pieza que usa authenticate()
    para decidir si rechazar sin mirar el password."""
    auth = AuthenticationSystem()
    user = User("user1", "hash", "active")
    user.locked_until = datetime.now() + timedelta(minutes=5)
    assert auth.is_time_lock_expired(user) is False


# ---------------------------------------------------------------------------
# Test de integracion: secuencia completa de bloqueo
# ---------------------------------------------------------------------------

def test_full_lockout_sequence_through_repeated_wrong_passwords():
    """Por que: los tests anteriores prueban cada zona por separado con
    estado precargado; este simula el flujo REAL, llamando a authenticate()
    cinco veces seguidas con password incorrecto y verificando que el
    sistema transiciona solo: normal (1-2) -> warning (3-4) -> bloqueado
    (5), y que una vez bloqueado, ni siquiera el password correcto entra
    en el intento 6. Es la prueba end-to-end de que las piezas sueltas
    (contador, umbrales, locked_until) funcionan juntas."""
    auth = AuthenticationSystem()
    user = User("user1", "correct_hash", "active")
    auth.users["user1"] = user

    expected = [
        (AuthResult.WRONG_PASSWORD, False),   # intento 1
        (AuthResult.WRONG_PASSWORD, False),   # intento 2
        (AuthResult.WRONG_PASSWORD, True),    # intento 3 -> entra en warning
        (AuthResult.WRONG_PASSWORD, True),    # intento 4
        (AuthResult.TOO_MANY_ATTEMPTS, True), # intento 5 -> se bloquea
    ]
    for expected_result, expected_alert in expected:
        result, increment, alert = auth.authenticate("user1", "wrong_password")
        assert result == expected_result
        assert alert == expected_alert

    assert user.locked_until is not None

    # Intento 6: aunque ahora se use el password correcto, sigue bloqueado.
    result, increment, alert = auth.authenticate("user1", "correct_hash")
    assert result == AuthResult.TOO_MANY_ATTEMPTS
